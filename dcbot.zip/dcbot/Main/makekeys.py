﻿import discord
from discord.ext import commands
from discord import app_commands
import json
import random
import string
import os
from datetime import datetime, timedelta

KEYS_PATH = "./Other Stuff/Keys.json"


# === Modal after selecting game ===
class KeyInfoModal(discord.ui.Modal, title="Key Details"):
    def __init__(self, bot, game):
        super().__init__()
        self.bot = bot
        self.game = game

        self.add_item(discord.ui.TextInput(
            label="How many keys?",
            placeholder="Example: 5",
            required=True
        ))
        self.add_item(discord.ui.TextInput(
            label="How long? (in days)",
            placeholder="Example: 7",
            required=True
        ))

    async def on_submit(self, interaction: discord.Interaction):
        try:
            count = int(self.children[0].value)
            days = int(self.children[1].value)

            if count < 1 or count > 100:
                return await interaction.response.send_message("❌ Key count must be between 1 and 100.", ephemeral=True)

            if not os.path.exists(KEYS_PATH):
                with open(KEYS_PATH, "w") as f:
                    json.dump({}, f)

            with open(KEYS_PATH, "r") as f:
                keys = json.load(f)

            expires_at = (datetime.utcnow() + timedelta(days=days)).strftime("%Y-%m-%d")
            new_keys = []

            for _ in range(count):
                key = ''.join(random.choices(string.ascii_uppercase + string.digits, k=16))
                while key in keys:
                    key = ''.join(random.choices(string.ascii_uppercase + string.digits, k=16))

                keys[key] = {
                    "game": self.game,
                    "duration_days": days,
                    "expires_at": expires_at,
                    "used": False,
                    "issued_by": str(interaction.user),
                    "redeemed_by": None
                }
                new_keys.append(key)

            with open(KEYS_PATH, "w") as f:
                json.dump(keys, f, indent=4)

            preview = "\n".join(new_keys[:5]) + ("\n..." if count > 5 else "")
            await interaction.response.send_message(
                f"✅ Generated `{count}` key(s) for `{self.game}` expiring in `{days}` day(s).\n```{preview}```",
                ephemeral=True
            )

            try:
                await interaction.user.send(
                    f"🔑 Your generated keys for `{self.game}` (expire in {days} days):\n```" +
                    "\n".join(new_keys) + "```"
                )
            except discord.Forbidden:
                await interaction.followup.send("⚠️ Couldn't DM you the keys. Please enable DMs.", ephemeral=True)

        except ValueError:
            await interaction.response.send_message("❌ Invalid input. Please enter numbers only.", ephemeral=True)


# === View for dropdown selection ===
class KeyGameDropdown(discord.ui.View):
    def __init__(self, bot):
        super().__init__(timeout=60)
        self.bot = bot

    @discord.ui.select(
        placeholder="Select the game for the key(s)...",
        options=[
            discord.SelectOption(label="Gorilla Tag", value="gtag"),
            discord.SelectOption(label="Fortnite", value="fn"),
            discord.SelectOption(label="Rainbow Six", value="r6")
        ]
    )
    async def select_callback(self, interaction: discord.Interaction, select: discord.ui.Select):
        await interaction.response.send_modal(KeyInfoModal(self.bot, select.values[0]))


# === Cog ===
class KeyGenCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="makekeys", description="Admin: Generate game keys")
    async def make_keys(self, interaction: discord.Interaction):
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message("🚫 Only admins can use this.", ephemeral=True)

        await interaction.response.send_message("🎮 Select the game for the keys:", view=KeyGameDropdown(self.bot), ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(KeyGenCog(bot))
