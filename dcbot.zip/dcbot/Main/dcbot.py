﻿import discord
from discord.ext import commands, tasks
from discord import app_commands
import json
import os
import asyncio
from datetime import datetime

# === Load token from Bot.json ===
with open('./Other Stuff/Bot.json', 'r') as f:
    data = json.load(f)
    TOKEN = data['token']

# === Set up bot ===
intents = discord.Intents.default()
bot = commands.Bot(command_prefix="!", intents=intents)

# === Load statuses from status.json ===
status_list = []
def load_statuses():
    global status_list
    try:
        with open('./Other Stuff/status.json', 'r', encoding='utf-8') as f:
            status_list = json.load(f)
    except Exception as e:
        print(f"Failed to load statuses: {e}")
        status_list = ["Online!"]

# === Status rotation loop ===
@tasks.loop(seconds=10)
async def status_loop():
    for status in status_list:
        await bot.change_presence(
            activity=discord.Activity(type=discord.ActivityType.watching, name=status)
        )
        await asyncio.sleep(10)

# === On Ready ===
@bot.event
async def on_ready():
    print(f"Logged in as {bot.user}!")
    try:
        synced = await bot.tree.sync()
        print(f"Synced {len(synced)} slash command(s).")
    except Exception as e:
        print(f"Error syncing commands: {e}")
    load_statuses()
    status_loop.start()

@bot.event
async def setup_hook():
    await bot.load_extension("Main.Cmds")
    await bot.load_extension("Main.TicketSystem")
    await bot.load_extension("Main.makekeys")
    await bot.load_extension("Main.redeem_key")
    await bot.load_extension("Main.keyexpire")
    await bot.load_extension("Main.help")
    await bot.load_extension("Main.modpanel")



# === Run Bot ===
bot.run(TOKEN)
