﻿import discord
from discord.ext import commands, tasks
import json
import os
from datetime import datetime

KEYS_PATH = "./Other Stuff/Keys.json"

# Role IDs per game (update these!)
ROLE_BY_GAME = {
    "gtag": 1373472871200067654,  # Gorilla Tag Role ID
    "fn": 1373472908915249272,    # Fortnite Role ID
    "r6": 1373472891437318174     # Rainbow Six Role ID
}


class KeyExpire(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.expire_keys.start()

    def cog_unload(self):
        self.expire_keys.cancel()

    @tasks.loop(hours=1)
    async def expire_keys(self):
        if not os.path.exists(KEYS_PATH):
            return

        with open(KEYS_PATH, "r") as f:
            keys = json.load(f)

        guild = self.bot.guilds[0] if self.bot.guilds else None
        if not guild:
            return

        updated = False
        expired_keys = []

        for key, data in keys.items():
            if not data.get("used"):
                continue

            expires_at = data.get("expires_at")
            if not expires_at:
                continue

            if datetime.utcnow().date() > datetime.strptime(expires_at, "%Y-%m-%d").date():
                user_tag = data.get("redeemed_by", "")
                name, _, disc = user_tag.partition("#")
                member = discord.utils.get(guild.members, name=name, discriminator=disc)

                role_id = ROLE_BY_GAME.get(data.get("game"))
                role = guild.get_role(role_id) if role_id else None

                if member and role and role in member.roles:
                    try:
                        await member.remove_roles(role)
                        print(f"✅ Removed expired role {role.name} from {member}")
                    except Exception as e:
                        print(f"⚠️ Failed to remove role from {member}: {e}")

                expired_keys.append(key)
                updated = True

        for key in expired_keys:
            del keys[key]

        if updated:
            with open(KEYS_PATH, "w") as f:
                json.dump(keys, f, indent=4)
            print(f"🧹 Expired {len(expired_keys)} keys.")

    @expire_keys.before_loop
    async def before_loop(self):
        await self.bot.wait_until_ready()


async def setup(bot: commands.Bot):
    await bot.add_cog(KeyExpire(bot))
