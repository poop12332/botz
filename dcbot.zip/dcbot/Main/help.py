﻿import discord
from discord.ext import commands
from discord import app_commands
import json

# Reuse your permission helpers
def get_user_perm_level(member):
    with open("./Other Stuff/Role Prem Lvl.json", "r") as f:
        role_map = json.load(f)
    for role in member.roles:
        if str(role.id) in role_map:
            return role_map[str(role.id)]
    return None

def get_perm_settings(level):
    with open("./Other Stuff/botperms.json", "r") as f:
        perms = json.load(f)
    return perms.get(str(level)) or {}

def has_perm(member, permission):
    level = get_user_perm_level(member)
    perms = get_perm_settings(level)
    return perms.get(permission, False)


class HelpCmd(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="help", description="Show all available commands")
    async def help(self, interaction: discord.Interaction):
        user = interaction.user

        embed = discord.Embed(
            title="📘 Bot Help",
            description="Here's a list of commands you can use:",
            color=discord.Color.blurple()
        )

        # General
        embed.add_field(
            name="📄 General",
            value="`/ping` - Check if the bot is alive\n"
                  "`/checkperm` - Show your premium level",
            inline=False
        )

        # Premium
        if has_perm(user, "can_use_extra"):
            embed.add_field(
                name="💎 Premium",
                value="`/premiumfeature` - Access premium content",
                inline=False
            )

        # Admin
        if has_perm(user, "can_use_admin"):
            embed.add_field(
                name="🛠️ Admin",
                value="`/adminpanel` - Admin controls\n"
                      "`/makekeys` - Generate access keys\n"
                      "`/update` - Post ticket panel\n"
                      "`/postredeem` - Post redeem panel",
                inline=False
            )

        # Fun
        embed.add_field(
            name="🎮 Fun",
            value="`/blackjack`, `/hug`, `/coinflip`, `/dice`, `/8ball`",
            inline=False
        )

        await interaction.response.send_message(embed=embed, ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(HelpCmd(bot))
