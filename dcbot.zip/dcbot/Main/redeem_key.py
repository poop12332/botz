﻿import discord
from discord.ext import commands
from discord import app_commands
import json
import os

# === Paths & Config ===
KEYS_PATH = "./Other Stuff/Keys.json"
REDEEM_CHANNEL = 1373465078548004896  # Replace with your real channel ID

# === Game-to-Role Mapping ===
ROLE_BY_GAME = {
    "gtag": 1373472871200067654,  # Gorilla Tag Role ID
    "fn": 1373472908915249272,    # Fortnite Role ID
    "r6": 1373472891437318174     # Rainbow Six Role ID
}


# === Modal to enter and redeem key ===
class RedeemKeyModal(discord.ui.Modal, title="Redeem Your Key"):
    def __init__(self):
        super().__init__()
        self.add_item(discord.ui.TextInput(
            label="Enter your key",
            placeholder="Paste your 16-character key",
            required=True
        ))

    async def on_submit(self, interaction: discord.Interaction):
        entered_key = self.children[0].value.strip().upper()

        if not os.path.exists(KEYS_PATH):
            return await interaction.response.send_message("❌ Key database not found.", ephemeral=True)

        with open(KEYS_PATH, "r") as f:
            keys = json.load(f)

        if entered_key not in keys:
            return await interaction.response.send_message("❌ That key is invalid.", ephemeral=True)

        key_data = keys[entered_key]

        if key_data.get("used"):
            return await interaction.response.send_message("❌ That key has already been used.", ephemeral=True)

        # Mark key as used and redeemed
        key_data["used"] = True
        key_data["redeemed_by"] = str(interaction.user)

        with open(KEYS_PATH, "w") as f:
            json.dump(keys, f, indent=4)

        # Assign role based on game
        game = key_data["game"]
        role_id = ROLE_BY_GAME.get(game)
        role = interaction.guild.get_role(role_id)

        if role:
            try:
                await interaction.user.add_roles(role)
                role_msg = f"🛡️ You have been given the **{role.name}** role."
            except discord.Forbidden:
                role_msg = "⚠️ I couldn’t assign your role. Please check my permissions."
        else:
            role_msg = "⚠️ No role configured for this game key."

        await interaction.response.send_message(
            f"✅ Successfully redeemed key for `{game}`!\n🕐 Access: `{key_data['duration_days']}` days\n{role_msg}",
            ephemeral=True
        )


# === View with the Redeem Button ===
class RedeemButton(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Redeem 🔑", style=discord.ButtonStyle.primary)
    async def redeem(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(RedeemKeyModal())


# === Cog to Post the Panel ===
class RedeemCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="postredeem", description="Admin: Post redeem panel")
    async def post_redeem_panel(self, interaction: discord.Interaction):
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message("🚫 Admin only.", ephemeral=True)

        embed = discord.Embed(
            title="Wh3 Studios",
            description="**Redeem Your Key**\nTo redeem your key, press the button below.",
            color=discord.Color.dark_theme()
        )
        embed.set_image(url="https://cdn.discordapp.com/attachments/1373437654972239929/1373470573480640654/90695497-vector-flat-icon-of-moon-on-black-background.jpg?ex=682a87a6&is=68293626&hm=12ed6e3079a36b978f274960be551f35287a32c5f9e276aa7160505a68face58&")
        embed.set_footer(text="Secure • Fast • Automated")

        channel = self.bot.get_channel(REDEEM_CHANNEL)
        if channel:
            await channel.send(embed=embed, view=RedeemButton())
            await interaction.response.send_message("✅ Redeem panel posted.", ephemeral=True)
        else:
            await interaction.response.send_message("❌ Could not find the redeem channel.", ephemeral=True)


# === Setup Cog ===
async def setup(bot: commands.Bot):
    await bot.add_cog(RedeemCog(bot))
