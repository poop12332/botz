﻿import discord
from discord.ext import commands
from discord import app_commands
import json, os


# === Permission Helpers ===

def get_user_perm_level(member):
    with open("./Other Stuff/Role Prem Lvl.json", "r") as f:
        role_map = json.load(f)
    for role in member.roles:
        if str(role.id) in role_map:
            return role_map[str(role.id)]
    return None


def get_perm_settings(level):
    with open("./Other Stuff/botperms.json", "r") as f:
        perms = json.load(f)
    return perms.get(str(level)) or {}

def has_perm(member, permission):
    level = get_user_perm_level(member)
    perms = get_perm_settings(level)
    return perms.get(permission, False)


# === Admin Action Modal ===

class AdminActionModal(discord.ui.Modal, title="Admin Action"):
    member_id = discord.ui.TextInput(label="Target User ID", placeholder="Paste user ID here")
    reason = discord.ui.TextInput(label="Reason", placeholder="Type the reason here", required=False)

    def __init__(self, action, bot):
        super().__init__()
        self.action = action
        self.bot = bot

    async def on_submit(self, interaction: discord.Interaction):
        guild = interaction.guild
        try:
            member = await guild.fetch_member(int(self.member_id.value))
        except:
            return await interaction.response.send_message("❌ Invalid user ID.", ephemeral=True)

        reason = self.reason.value or "No reason provided"

        # === Ban ===
        if self.action == "ban":
            if not has_perm(interaction.user, "can_ban"):
                return await interaction.response.send_message("🚫 You can't ban.", ephemeral=True)
            try: await member.send(f"You were banned: {reason}")
            except: pass
            await guild.ban(member, reason=reason)
            return await interaction.response.send_message(f"✅ Banned {member}", ephemeral=True)

        # === Kick ===
        elif self.action == "kick":
            if not has_perm(interaction.user, "can_kick"):
                return await interaction.response.send_message("🚫 You can't kick.", ephemeral=True)
            try: await member.send(f"You were kicked: {reason}")
            except: pass
            await guild.kick(member, reason=reason)
            return await interaction.response.send_message(f"✅ Kicked {member}", ephemeral=True)

        # === Mute ===
        elif self.action == "mute":
            if not has_perm(interaction.user, "can_mute"):
                return await interaction.response.send_message("🚫 You can't mute.", ephemeral=True)
            muted_role = discord.utils.get(guild.roles, name="Muted")
            if not muted_role:
                muted_role = await guild.create_role(name="Muted")
                for channel in guild.channels:
                    await channel.set_permissions(muted_role, send_messages=False, speak=False)
            await member.add_roles(muted_role)
            try: await member.send(f"You were muted: {reason}")
            except: pass
            return await interaction.response.send_message(f"✅ Muted {member}", ephemeral=True)

        # === Warn ===
        elif self.action == "warn":
            if not has_perm(interaction.user, "can_warn"):
                return await interaction.response.send_message("🚫 You can't warn.", ephemeral=True)
            path = "./Other Stuff/warnings.json"
            if not os.path.exists(path):
                with open(path, "w") as f:
                    json.dump({}, f)
            with open(path, "r") as f:
                data = json.load(f)
            uid = str(member.id)
            if uid not in data:
                data[uid] = []
            data[uid].append({"reason": reason, "moderator": interaction.user.name})
            with open(path, "w") as f:
                json.dump(data, f, indent=4)
            try: await member.send(f"You were warned: {reason}")
            except: pass
            return await interaction.response.send_message(f"⚠️ Warned {member}", ephemeral=True)

        # === Check Warnings ===
        elif self.action == "check warnings":
            if not has_perm(interaction.user, "can_check_warnings"):
                return await interaction.response.send_message("🚫 You can't view warnings.", ephemeral=True)
            with open("./Other Stuff/warnings.json", "r") as f:
                warnings = json.load(f)
            uid = str(member.id)
            if uid not in warnings or not warnings[uid]:
                return await interaction.response.send_message("✅ No warnings for this user.", ephemeral=True)
            msg = "\n".join([f"{i+1}. {w['reason']} by {w['moderator']}" for i, w in enumerate(warnings[uid])])
            return await interaction.response.send_message(f"⚠️ Warnings for {member}:\n{msg}", ephemeral=True)


# === Admin Dropdown Menu ===

class AdminMenu(discord.ui.View):
    def __init__(self, author, bot):
        super().__init__(timeout=None)
        self.author = author
        self.bot = bot

    @discord.ui.select(
        placeholder="Choose an admin action...",
        min_values=1,
        max_values=1,
        options=[
            discord.SelectOption(label="Ban", description="Ban a user"),
            discord.SelectOption(label="Kick", description="Kick a user"),
            discord.SelectOption(label="Mute", description="Mute a user"),
            discord.SelectOption(label="Warn", description="Warn a user"),
            discord.SelectOption(label="Check Warnings", description="View a user's warnings")
        ]
    )
    async def select_callback(self, interaction: discord.Interaction, select: discord.ui.Select):
        if interaction.user != self.author:
            return await interaction.response.send_message("🚫 This isn't your menu.", ephemeral=True)
        await interaction.response.send_modal(AdminActionModal(select.values[0].lower(), self.bot))


# === Main Bot Commands ===

class Cmds(commands.Cog):
    def __init__(self, bot):
        self.bot = bot


    # === Ping ===
    @app_commands.command(name="ping", description="Check if the bot is alive")
    async def ping(self, interaction: discord.Interaction):
        await interaction.response.send_message("🏓 Pong!", ephemeral=True)


    # === Check Permission ===
    @app_commands.command(name="checkperm", description="Check your premium level")
    async def checkperm(self, interaction: discord.Interaction):
        level = get_user_perm_level(interaction.user)
        if not level:
            return await interaction.response.send_message("❌ No premium role found.", ephemeral=True)
        perms = get_perm_settings(level)
        desc = perms.get("description", "Unknown")
        await interaction.response.send_message(f"✅ Level `{level}`: {desc}", ephemeral=True)


    # === Premium Feature ===
    @app_commands.command(name="premiumfeature", description="A feature for premium users")
    async def premiumfeature(self, interaction: discord.Interaction):
        if has_perm(interaction.user, "can_use_extra"):
            await interaction.response.send_message("✨ Welcome to the premium feature!", ephemeral=True)
        else:
            await interaction.response.send_message("🔒 Premium access required.", ephemeral=True)


    # === Admin Panel (Dropdown) ===
    @app_commands.command(name="adminpanel", description="Admin control panel")
    async def adminpanel(self, interaction: discord.Interaction):
        if not has_perm(interaction.user, "can_use_admin"):
            return await interaction.response.send_message("🚫 You don’t have admin access.", ephemeral=True)
        view = AdminMenu(interaction.user, self.bot)
        await interaction.response.send_message("🔧 Select an action below:", view=view, ephemeral=True)


    # === Blackjack ===
    @app_commands.command(name="blackjack", description="Play blackjack against the bot")
    async def blackjack(self, interaction: discord.Interaction):
        import random

        def draw_card():
            return random.choice(["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"])

        def card_value(card):
            if card in ["J", "Q", "K"]:
                return 10
            elif card == "A":
                return 11
            else:
                return int(card)

        user_cards = [draw_card(), draw_card()]
        bot_cards = [draw_card(), draw_card()]

        def calc_score(cards):
            score = sum(card_value(c) for c in cards)
            aces = cards.count("A")
            while score > 21 and aces:
                score -= 10
                aces -= 1
            return score

        user_score = calc_score(user_cards)
        bot_score = calc_score(bot_cards)

        result = f"🃏 You: {user_cards} ({user_score})\n🤖 Bot: {bot_cards} ({bot_score})\n"

        if user_score > 21:
            result += "💥 You busted! Bot wins!"
        elif bot_score > 21 or user_score > bot_score:
            result += "🎉 You win!"
        elif user_score < bot_score:
            result += "😢 You lose!"
        else:
            result += "🤝 It's a tie!"

        await interaction.response.send_message(result, ephemeral=True)


    # === Hug ===
    @app_commands.command(name="hug", description="Send a virtual hug to someone")
    async def hug(self, interaction: discord.Interaction, user: discord.User):
        await interaction.response.send_message(f"🤗 {interaction.user.mention} gives a big hug to {user.mention}!")


    # === Coinflip ===
    @app_commands.command(name="coinflip", description="Flip a coin")
    async def coinflip(self, interaction: discord.Interaction):
        import random
        result = random.choice(["🪙 Heads", "🪙 Tails"])
        await interaction.response.send_message(f"{interaction.user.mention} flipped a coin... {result}!")


    # === Dice ===
    @app_commands.command(name="dice", description="Roll a dice with X sides")
    async def dice(self, interaction: discord.Interaction, sides: int = 6):
        import random
        if sides < 2:
            return await interaction.response.send_message("⚠️ Dice must have at least 2 sides.", ephemeral=True)
        result = random.randint(1, sides)
        await interaction.response.send_message(f"🎲 {interaction.user.mention} rolled a **{result}** on a {sides}-sided die!")


    # === 8Ball ===
    @app_commands.command(name="8ball", description="Ask the magic 8-ball a question")
    async def eightball(self, interaction: discord.Interaction, question: str):
        import random
        answers = [
            "Yes!", "No.", "Maybe...", "Absolutely!", "Definitely not.",
            "Ask again later.", "I don't think so.", "It is certain.", "Very doubtful."
        ]
        reply = random.choice(answers)
        await interaction.response.send_message(f"🎱 You asked: *{question}*\n🎱 8Ball says: **{reply}**")

# === Setup ===
async def setup(bot: commands.Bot):
    await bot.add_cog(Cmds(bot))
