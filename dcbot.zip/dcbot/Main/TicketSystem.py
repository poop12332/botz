﻿import discord
from discord.ext import commands
from discord import app_commands
import json
import os

# === Load Configs ===
with open('./Other Stuff/ticket_config.json', 'r') as f:
    TICKET_CONFIG = json.load(f)

with open('./Other Stuff/ticket_text.json', 'r') as f:
    TICKET_TEXT = json.load(f)


# === Button to Close Ticket ===
class CloseTicketButton(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="🔒 Close Ticket", style=discord.ButtonStyle.danger)
    async def close(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not interaction.channel.name.startswith(("buy-", "support-", "bug-")):
            return await interaction.response.send_message("❌ This isn't a ticket channel.", ephemeral=True)

        await interaction.response.send_message("🗂️ Closing ticket...", ephemeral=True)
        await interaction.channel.delete()


# === Modal for Ticket Info ===
class TicketModal(discord.ui.Modal):
    def __init__(self, reason, bot):
        config = TICKET_TEXT[reason]
        super().__init__(title=config["title"])
        self.reason = reason
        self.bot = bot

        self.add_item(discord.ui.TextInput(
            label=config["field1_label"],
            placeholder=config["field1_placeholder"],
            required=True
        ))
        self.add_item(discord.ui.TextInput(
            label=config["field2_label"],
            placeholder=config["field2_placeholder"],
            required=True,
            style=discord.TextStyle.paragraph
        ))

    async def on_submit(self, interaction: discord.Interaction):
        user = interaction.user
        guild = interaction.guild

        # Prevent duplicate tickets
        for channel in guild.text_channels:
            if channel.name == f"{self.reason}-{user.id}":
                return await interaction.response.send_message("⚠️ You already have an open ticket.", ephemeral=True)

        # Permissions
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            user: discord.PermissionOverwrite(view_channel=True, send_messages=True)
        }

        for role_id in TICKET_CONFIG["support_role_ids"]:
            role = guild.get_role(role_id)
            if role:
                overwrites[role] = discord.PermissionOverwrite(view_channel=True, send_messages=True)

        # Create ticket channel
        category_id = TICKET_CONFIG["ticket_categories"].get(self.reason)
        category = discord.utils.get(guild.categories, id=category_id)

        channel = await guild.create_text_channel(
            name=f"{self.reason}-{user.id}",
            category=category,
            overwrites=overwrites
        )

        val1 = self.children[0].value
        val2 = self.children[1].value
        labels = TICKET_TEXT[self.reason]

        embed = discord.Embed(
            title=labels["title"],
            description="Please wait while our team responds.",
            color=discord.Color.blurple()
        )
        embed.add_field(name="User", value=user.mention, inline=False)
        embed.add_field(name=labels["field1_label"], value=val1, inline=True)
        embed.add_field(name=labels["field2_label"], value=val2, inline=False)
        embed.set_footer(text="Support Bot • Respect staff and rules.")

        await channel.send(content=user.mention, embed=embed, view=CloseTicketButton())
        await interaction.response.send_message(f"✅ Ticket created: {channel.mention}", ephemeral=True)


# === Dropdown to Select Ticket Type ===
class TicketDropdown(discord.ui.View):
    def __init__(self, bot):
        super().__init__(timeout=None)
        self.bot = bot

    @discord.ui.select(
        placeholder="Open a ticket for...",
        options=[
            discord.SelectOption(label="Buyer", value="buy", description="Help with a purchase"),
            discord.SelectOption(label="Support", value="support", description="Product or account help"),
            discord.SelectOption(label="Report Bug", value="bug", description="Report an issue or error")
        ]
    )
    async def select_callback(self, interaction: discord.Interaction, select: discord.ui.Select):
        await interaction.response.send_modal(TicketModal(select.values[0], self.bot))


# === Main Ticket System Cog ===
class TicketCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="update", description="Post the ticket panel (admin only)")
    async def update_ticket_panel(self, interaction: discord.Interaction):
        if not interaction.user.guild_permissions.administrator:
            return await interaction.response.send_message("❌ Admins only.", ephemeral=True)

        embed = discord.Embed(
            title="📩 Open a Support Ticket",
            description="Need help? Use the dropdown below to open a ticket.",
            color=discord.Color.dark_theme()
        )
        embed.set_image(url="https://cdn.discordapp.com/attachments/1373437654972239929/1373470573480640654/90695497-vector-flat-icon-of-moon-on-black-background.jpg?ex=682a87a6&is=68293626&hm=12ed6e3079a36b978f274960be551f35287a32c5f9e276aa7160505a68face58&")
        embed.set_footer(text="Support Bot • Your message will be seen by staff.")

        channel = self.bot.get_channel(TICKET_CONFIG["panel_channel_id"])
        if channel:
            await channel.send(embed=embed, view=TicketDropdown(self.bot))
            await interaction.response.send_message("✅ Ticket panel posted!", ephemeral=True)
        else:
            await interaction.response.send_message("❌ Could not find the panel channel.", ephemeral=True)


# === Setup ===
async def setup(bot: commands.Bot):
    await bot.add_cog(TicketCog(bot))
