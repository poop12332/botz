﻿import discord
from discord.ext import commands
from discord import app_commands
import json

# === Permission Helpers ===
def get_user_perm_level(member):
    with open("./Other Stuff/Role Prem Lvl.json", "r") as f:
        role_map = json.load(f)
    for role in member.roles:
        if str(role.id) in role_map:
            return role_map[str(role.id)]
    return None

def get_perm_settings(level):
    with open("./Other Stuff/botperms.json", "r") as f:
        perms = json.load(f)
    return perms.get(str(level)) or {}

def has_perm(member, permission):
    level = get_user_perm_level(member)
    perms = get_perm_settings(level)
    return perms.get(permission, False)


# === Modal from Admin System ===
class AdminActionModal(discord.ui.Modal, title="Moderation Action"):
    member_id = discord.ui.TextInput(label="Target User ID", placeholder="Paste user ID here")
    reason = discord.ui.TextInput(label="Reason", placeholder="Why are you doing this?", required=False)

    def __init__(self, action, bot):
        super().__init__()
        self.action = action
        self.bot = bot

    async def on_submit(self, interaction: discord.Interaction):
        guild = interaction.guild
        try:
            member = await guild.fetch_member(int(self.member_id.value))
        except:
            return await interaction.response.send_message("❌ Invalid user ID.", ephemeral=True)

        reason = self.reason.value or "No reason provided"

        if self.action == "ban" and not has_perm(interaction.user, "can_ban"):
            return await interaction.response.send_message("🚫 You can't ban.", ephemeral=True)
        if self.action == "kick" and not has_perm(interaction.user, "can_kick"):
            return await interaction.response.send_message("🚫 You can't kick.", ephemeral=True)
        if self.action == "mute" and not has_perm(interaction.user, "can_mute"):
            return await interaction.response.send_message("🚫 You can't mute.", ephemeral=True)
        if self.action == "warn" and not has_perm(interaction.user, "can_warn"):
            return await interaction.response.send_message("🚫 You can't warn.", ephemeral=True)
        if self.action == "check warnings" and not has_perm(interaction.user, "can_check_warnings"):
            return await interaction.response.send_message("🚫 You can't view warnings.", ephemeral=True)

        if self.action == "ban":
            try: await member.send(f"You were banned: {reason}")
            except: pass
            await guild.ban(member, reason=reason)
            return await interaction.response.send_message(f"✅ Banned {member}", ephemeral=True)

        elif self.action == "kick":
            try: await member.send(f"You were kicked: {reason}")
            except: pass
            await guild.kick(member, reason=reason)
            return await interaction.response.send_message(f"✅ Kicked {member}", ephemeral=True)

        elif self.action == "mute":
            muted_role = discord.utils.get(guild.roles, name="Muted")
            if not muted_role:
                muted_role = await guild.create_role(name="Muted")
                for channel in guild.channels:
                    await channel.set_permissions(muted_role, send_messages=False, speak=False)
            await member.add_roles(muted_role)
            try: await member.send(f"You were muted: {reason}")
            except: pass
            return await interaction.response.send_message(f"✅ Muted {member}", ephemeral=True)

        elif self.action == "warn":
            path = "./Other Stuff/warnings.json"
            if not os.path.exists(path):
                with open(path, "w") as f:
                    json.dump({}, f)
            with open(path, "r") as f:
                data = json.load(f)
            uid = str(member.id)
            if uid not in data:
                data[uid] = []
            data[uid].append({"reason": reason, "moderator": interaction.user.name})
            with open(path, "w") as f:
                json.dump(data, f, indent=4)
            try: await member.send(f"You were warned: {reason}")
            except: pass
            return await interaction.response.send_message(f"⚠️ Warned {member}", ephemeral=True)

        elif self.action == "check warnings":
            with open("./Other Stuff/warnings.json", "r") as f:
                warnings = json.load(f)
            uid = str(member.id)
            if uid not in warnings or not warnings[uid]:
                return await interaction.response.send_message("✅ No warnings for this user.", ephemeral=True)
            msg = "\n".join([f"{i+1}. {w['reason']} by {w['moderator']}" for i, w in enumerate(warnings[uid])])
            return await interaction.response.send_message(f"📋 Warnings for {member}:\n{msg}", ephemeral=True)


# === View with Dropdown for Mods ===
class ModPanelView(discord.ui.View):
    def __init__(self, author, bot):
        super().__init__(timeout=None)
        self.author = author
        self.bot = bot

    @discord.ui.select(
        placeholder="Choose a moderation action...",
        options=[
            discord.SelectOption(label="Mute", description="Mute a user"),
            discord.SelectOption(label="Warn", description="Warn a user"),
            discord.SelectOption(label="Check Warnings", description="See warning history")
        ]
    )
    async def select_callback(self, interaction: discord.Interaction, select: discord.ui.Select):
        if interaction.user != self.author:
            return await interaction.response.send_message("❌ This isn't your panel.", ephemeral=True)
        await interaction.response.send_modal(AdminActionModal(select.values[0].lower(), self.bot))


# === Slash Command ===
class ModPanel(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="modpanel", description="Open the moderator panel")
    async def modpanel(self, interaction: discord.Interaction):
        if not has_perm(interaction.user, "can_warn"):  # minimal mod check
            return await interaction.response.send_message("🚫 You don’t have access to this panel.", ephemeral=True)

        view = ModPanelView(interaction.user, self.bot)
        await interaction.response.send_message("🛠️ Select a moderation action below:", view=view, ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(ModPanel(bot))
